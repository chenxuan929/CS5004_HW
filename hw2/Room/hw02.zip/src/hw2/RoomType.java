package hw2;

/**
 * Enumeration for the types of rooms.
 */
public enum RoomType {
  SINGLE, DOUBLE, FAMILY;
}
