package cs5004.collections;

/**
 * EmptyPriorityQueueException class to throw empty exception.
 */
public class EmptyPriorityQueueException extends Exception {
}