package questionnaire;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Questionnaire implementation using an ArrayList and a HashMap.
 */
public class QuestionnaireImpl implements Questionnaire {
  private List<Question> questions;
  private Map<String, Question> questionMap;

  /**
   * Constructor that creates an empty questionnaire.
   */
  public QuestionnaireImpl() {
    this.questions = new ArrayList<>();
    this.questionMap = new HashMap<>();
  }

  /**
   * Add questions to questionnaire.
   * @param identifier a name for the question <b>unique</b> within this questionnaire. Not null
   *                   or empty.
   * @param q the {@link Question} to be added to the questionnaire.
   */
  @Override
  public void addQuestion(String identifier, Question q) {
    if (identifier == null || identifier.isEmpty()) {
      throw new IllegalArgumentException("Identifier cannot be null or empty.");
    }
    if (q == null) {
      throw new IllegalArgumentException("Question cannot be null.");
    }
    if (questionMap.containsKey(identifier)) {
      throw new IllegalArgumentException("identifier has occurred.");
    }
    questionMap.put(identifier, q);
    questions.add(q);
  }

  /**
   * Remove question from questionnaire.
   * @param identifier the identifier of the question to be removed.
   */
  @Override
  public void removeQuestion(String identifier) {
    if (identifier == null || identifier.isEmpty()) {
      throw new IllegalArgumentException("Identifier cannot be null or empty.");
    }
    Question q = questionMap.get(identifier);
    if (q == null) {
      throw new NoSuchElementException("Question related this identifier is null.");
    }
    if (questionMap.containsKey(identifier)) {
      questionMap.remove(identifier);
      questions.remove(q);
    }
  }

  /**
   * Get the question with the given number.
   * @param num the number of the question, counting from 1.
   * @return question.
   */
  @Override
  public Question getQuestion(int num) {
    if (num < 1 || num > questions.size()) {
      throw new IndexOutOfBoundsException("No such question num.");
    }
    return questions.get(num - 1);
  }

  /**
   * Get the question with the given identifier.
   * @param identifier the identifier of the question
   * @return question.
   */
  @Override
  public Question getQuestion(String identifier) {
    if (identifier == null) {
      throw new IllegalArgumentException("Identifier cannot be null.");
    }
    if (!questionMap.containsKey(identifier)) {
      throw new NoSuchElementException("No question with the identifier.");
    }
    return questionMap.get(identifier);
  }

  /**
   * Get require question.
   * @return list of require questions.
   */
  @Override
  public List<Question> getRequiredQuestions() {
    return questions.stream()
      .filter(Question::isRequired)
      .collect(Collectors.toList());
  }

  /**
   * Get list of optional questions.
   * @return list of question.
   */
  @Override
  public List<Question> getOptionalQuestions() {
    return questions.stream()
      .filter(q -> !q.isRequired())
      .collect(Collectors.toList());
  }

  /**
   * Check if all question is complete.
   * @return boolean.
   */
  @Override
  public boolean isComplete() {
    return questions.stream()
      .filter(Question::isRequired)
      .noneMatch(q -> q.getAnswer().isEmpty());
  }

  /**
   * Get the response.
   * @return list of response.
   */
  @Override
  public List<String> getResponses() {
    return questions.stream()
        .map(Question::getAnswer)
        .collect(Collectors.toList());
  }

  /**
   * Filter questionnaire with given predicate.
   * @param pq the predicate.
   * @return copy of filtered questionnaire.
   */
  @Override
  public Questionnaire filter(Predicate<Question> pq) {
    if (pq == null) {
      throw new IllegalArgumentException("Predicate is null");
    }
    List<Question> f = this.questions.stream()
        .filter(pq) //satisfy pq condition.
        .map(Question::copy) //use copy method from Question interface.
        .collect(Collectors.toList()); //get the list of a Question called 'f'.

    QuestionnaireImpl filteredQuestionnaire = new QuestionnaireImpl();
    //Produce a new questionnaire as asked.
    for (Question q : f) { //for each q in list, add prompt.
      if (q == null) {
        throw new IllegalArgumentException("Question cannot be null.");
      }
      filteredQuestionnaire.addQuestion(q.getPrompt(), q);
    }
    return filteredQuestionnaire;
  }

  /**
   * Sort the questions according to the given comparator.
   * @param comp a comparator for Question.
   */
  @Override
  public void sort(Comparator<Question> comp) {
    if (comp == null) {
      throw new IllegalArgumentException("Comparator cannot be null.");
    }
    List<Question> sortQuestions = questions.stream()
        .sorted(comp)
        .collect(Collectors.toList());
    this.questions = sortQuestions;
  }

  /**
   * Rroduce the summary value for folding function.
   * @param bf the folding function.
   * @param seed the seed value.
   * @return summary value.
   */
  @Override
  public <R> R fold(BiFunction<Question, R, R> bf, R seed) {
    if (bf == null) {
      throw new IllegalArgumentException("BiFunction cannot be null.");
    }
    R summary = seed;
    for (Question q: this.questions) {
      if (q == null) {
        throw new IllegalArgumentException("Question cannot be null.");
      }
      summary = bf.apply(q, summary);
    }
    return summary;
  }

  /**
   * Override toString method.
   * @return string.
   */
  @Override
  public String toString() {
    StringBuilder toS = new StringBuilder();
    for (int i = 0; i < this.questions.size(); i++) {
      Question q = this.questions.get(i);
      toS.append("Question: ").append(q.getPrompt()).append("\n\n")
        .append("Answer: ").append(q.getAnswer());
      if (i < this.questions.size() - 1) {
        toS.append("\n\n");
      }
    }
    return toS.toString();
  }
}
