package questionnaire;

/**
 * Likert class implement Question interface.
 */
public class Likert implements Question {
  private String prompt;
  private boolean require;
  private String answer;

  /**
   * Constructor of Likert class.
   */
  public Likert(String prompt, boolean require) {
    if (prompt == null) {
      throw new IllegalArgumentException("question can not be null");
    }
    this.prompt = prompt;
    this.require = require;
    this.answer = null;
  }

  /**
   * Get the prompt of the question itself.
   * @return prompt.
   */
  @Override
  public String getPrompt() {
    return this.prompt;
  }

  /**
   * Get the adjacency if is required.
   * @return boolean.
   */
  @Override
  public boolean isRequired() {
    return this.require;
  }

  /**
   * Check if the answer is valid.
   * @param answer answer of question.
   */
  @Override
  public void answer(String answer) {
    if (answer == null) {
      throw new IllegalArgumentException("Answer cannot be null.");
    }
    boolean ans = false;
    for (LikertResponseOption option : LikertResponseOption.values()) {
      if (answer.equalsIgnoreCase(option.getText())) {
        this.answer = answer;
        ans = true;
        break;
      }
    }
    if (!ans) {
      throw new IllegalArgumentException("Invalid answer");
    }
  }

  /**
   * Get the answer.
   * @return answer.
   */
  @Override
    public String getAnswer() {
    if (this.answer != null) {
      return answer;
    } else {
      return "";
    }
  }

  /**
   * Copy the constructor.
   * @return copy
   */
  @Override
  public Question copy() {
    Likert copy = new Likert(this.prompt, this.require);
    if (this.answer != null) {
      copy.answer(getAnswer());
    }
    return copy;
  }
}
