package questionnaire;

/**
 * ShortAnswer class implement Question interface.
 */
public class ShortAnswer implements Question {
  private String prompt;
  private boolean require;
  private String answer;

  /**
   * Constructor of ShortAnswer class.
   */
  public ShortAnswer(String prompt, boolean require) {
    if (prompt == null) {
      throw new IllegalArgumentException("question can not be null");
    }
    this.prompt = prompt;
    this.require = require;
    this.answer = "";
  }

  /**
   * Get the prompt of the question itself.
   * @return prompt.
   */
  @Override
  public String getPrompt() {
    return this.prompt;
  }

  /**
   * Get the adjust if is required.
   * @return boolean.
   */
  @Override
  public boolean isRequired() {
    return this.require;
  }

  /**
   * Check if the answer is valid.
   * @param answer answer of question.
   */
  @Override
  public void answer(String answer) {
    if (answer == null) {
      throw new IllegalArgumentException("Answer can not be null");
    }
    if (answer.length() <= 280) {
      this.answer = answer;
    } else {
      throw new IllegalArgumentException("invalid answer");
    }
  }


  /**
   * Get the answer.
   * @return answer.
   */
  @Override
  public String getAnswer() {
    return this.answer;
  }

  /**
   * Copy the constructor.
   * @return copy
   */
  @Override
  public Question copy() {
    ShortAnswer copy = new ShortAnswer(this.prompt, this.require);
    copy.answer(getAnswer());
    return copy;
  }
}
