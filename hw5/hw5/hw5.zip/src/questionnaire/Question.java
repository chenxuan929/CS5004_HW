package questionnaire;

/**
 * Question interface.
 */
public interface Question {

  /**
   * Get the prompt of the question.
   */
  String getPrompt();

  /**
   * Get the boolean value represent if is required.
   */
  boolean isRequired();

  /**
   * Enter a string and accept word as answers.
   */
  void answer(String answer);

  /**
   * Get the answer of question.
   */
  String getAnswer();

  /**
   * Copy the constructor.
   */
  Question copy();

}
