package encryption;
public interface IEncryption {
  String encode(int encoding);
}

