package chess;

/**
 * Enumeration for the color of chess.
 */
public enum Color {
    BLACK, WHITE
}
