package registration;

import java.util.List;

/**
 * IRegistration interface.
 */
public interface IRegistration {

  /**
   * Get the registration year of vehicle.
   * @return registration year of vehicle.
   */
  int getRegistrationYear();

  /**
   * Get the production year of vehicle.
   * @return production year of vehicle.
   */
  int getProductionYear();

  /**
   * Get the jurisdiction of vehicle.
   * @return jurisdiction of vehicle.
   */
  IJurisdiction getJurisdiction();

  /**
   * Get owner of vehicle.
   * @return owner of vehicle.
   */
  List<Person> getOwners();      // return NON-MUTABLE list

  /**
   * Get the max passengers of vehicle.
   * @return max passengers of vehicle.
   */
  int getMaxPassengers();

  /**
   * Calculate the excise tax of vehicle.
   * @return excise tax of vehicle.
   */
  double calculateExciseTax();
}
